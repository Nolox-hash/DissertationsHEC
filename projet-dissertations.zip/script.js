// Liste des modules et leurs titres
const modules = [
    { id: "histoire", name: "Économie, Sociologie et Histoire" },
    { id: "culture", name: "Culture Générale" },
    { id: "english", name: "English Essay" },
    { id: "deutsch", name: "Deutsche Essay" },
    { id: "mission", name: "Mission de Dissertations HEC" }
];

// Sélection de l'élément où seront affichés les modules
const container = document.getElementById("modules-container");

// Générer les modules dynamiquement
modules.forEach(module => {
    const div = document.createElement("div");
    div.classList.add("module");
    div.dataset.module = module.id;
    div.innerHTML = `<span>${module.name}</span>`;

    // Ajouter un événement de clic
    div.addEventListener("click", () => {
        window.location.href = `module.html?module=${module.id}`;
    });

    container.appendChild(div);
});
